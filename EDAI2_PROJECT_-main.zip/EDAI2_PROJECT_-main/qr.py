import qrcode
import bcrypt

def generate_qr_code_with_password(data, password):
    # Generate QR code
    qr = qrcode.QRCode(version=1, box_size=10, border=5)
    qr.add_data(data)
    qr.make(fit=True)
    qr_img = qr.make_image(fill_color="black", back_color="white")

    # Encrypt password
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())

    # Save the QR code image with password
    qr_img.save('qr_code.png')
    with open('password.txt', 'w') as f:
        f.write(hashed_password.decode('utf-8'))

# Example usage
data = 'Hello, World!'
password = 'mysecret'

generate_qr_code_with_password(data, password)
